﻿using LibTest.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace LibTest.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly OnlineLibraryContext _db;

        public HomeController(ILogger<HomeController> logger, OnlineLibraryContext db)
        {
            _logger = logger;
            _db = db;
        }
        [Authorize]
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet("login")]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost("login")]
        public async Task<IActionResult> Login(string email, string password)
        {
            var AccountObj = _db.Accounts.Where(x => x.Email.Equals(email) && x.Passowrd.Equals(password)).FirstOrDefault<Account>();
            if(AccountObj != null)
            {
                var claims = new List<Claim>();
                claims.Add(new Claim("Email", AccountObj.Email));
                claims.Add(new Claim(ClaimTypes.NameIdentifier, AccountObj.Email));
                claims.Add(new Claim(ClaimTypes.Name, (AccountObj.LastName + "," + AccountObj.FirstName)));
                claims.Add(new Claim(ClaimTypes.Role, AccountObj.Role));


                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);
                await HttpContext.SignInAsync(claimsPrincipal);
                if (AccountObj.Role.Equals("Employee"))
                {
                    return RedirectToAction("Employee");
                }
                else if (AccountObj.Role.Equals("Customer"))
                {
                    return RedirectToAction("Customer");
                }
                return NotFound();
            }
            TempData["Error"] = "The Email or Password Entered Is Invalid";
            return View("Login");
        }
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync();
            return RedirectToAction("Login");
        }
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(Account AccountObj)
        {
            if (ModelState.IsValid)
            {
                _db.Accounts.Add(AccountObj);
                _db.SaveChanges();
                return RedirectToAction("Login");

            }
            return View(AccountObj);
        }

        public IActionResult Employee()
        {
            IEnumerable <Book> BookList = _db.Books;
            return View(BookList);
        }
        public IActionResult Customer()
        {
            IEnumerable<Book> BookList = _db.Books;
            return View(BookList);
        }
        public IActionResult Borrow()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Modify(int?id)
        {
            
            if(id == null || id == 0)
            {
                return NotFound();
            }
            else
            {
                var BookObj = _db.Books.Find(id);
                if(BookObj == null)
                {
                    return NotFound();
                }
                return View(BookObj);
            }     

        }
        [HttpPost]
        public IActionResult Modify(Book obj)
        {
            if (ModelState.IsValid)
            {
                _db.Books.Update(obj);
                _db.SaveChanges();
                return RedirectToAction("Employee");
            }
            return View(obj);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Book obj)
        {
            if (ModelState.IsValid)
            {
                _db.Books.Add(obj);
                _db.SaveChanges();
                return RedirectToAction("Employee");
            }
            return View(obj);
        }
        [HttpGet]
        public IActionResult Remove(int id)
        {
            if (id == 0)
            {
                return NotFound();
            }
            else
            {
                var BookObj = _db.Books.Find(id);
                if (BookObj == null)
                {
                    return NotFound();
                }
                return View(BookObj);
            }
        }
        [HttpPost]
        public IActionResult Remove(Book BookObj)
        {
            _db.Books.Remove(BookObj);
            _db.SaveChanges();
            return RedirectToAction("Employee");
        }
        [HttpGet]
        public IActionResult AddAdmin()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddAdmin(Account Obj)
        {
            if (ModelState.IsValid)
            {
                _db.Accounts.Add(Obj);
                _db.SaveChanges();
                return RedirectToAction("Employee");
            }
            return View(Obj);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
