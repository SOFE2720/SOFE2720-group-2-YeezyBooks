﻿using System;
using System.Collections.Generic;

#nullable disable

namespace LibTest.Models
{
    public partial class Book
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Genre { get; set; }
        public int Copies { get; set; }
        public string BookCover { get; set; }
        public string BookRating { get; set; }
    }
}
