﻿using System;
using System.Collections.Generic;

#nullable disable

namespace LibTest.Models
{
    public partial class Borrowing
    {
        public int BorrowId { get; set; }
        public long CardNumber { get; set; }
        public int BookId { get; set; }
        public DateTime BorrowDate { get; set; }
        public DateTime ReturnDate { get; set; }
        public decimal Fine { get; set; }
    }
}
