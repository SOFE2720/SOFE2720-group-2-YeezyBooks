﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

#nullable disable

namespace LibTest.Models
{
    public partial class Account
    {
        [DisplayName("Last Four Digits of your Card Number")]
        public long CardNumber { get; set; }
        [DisplayName("Date Of Birth")]
        public DateTime Dob { get; set; }
        [DisplayName("Last Name")]
        public string LastName { get; set; }
        [DisplayName("First Name")]
        public string FirstName { get; set; }
        public string Email { get; set; }
        public string Passowrd { get; set; }
        public string Role { get; set; }
    }
}
